const TaskOperation = {
  alltask: <TaskType[]>[],

  getAllTask() {
    return this.alltask;
  },
  addTask(taskObj: TaskType) {
    this.alltask.push(taskObj);
  },
  updateTask(taskObj: TaskType) {
    this.deleteTask(taskObj.id);
    this.addTask(taskObj);
  },
  deleteTask(id: string) {
    const afterDelete = this.alltask.filter((item) => item.id !== id);
    this.alltask = afterDelete;
    return this.alltask;
  },
  searchTask(id: any) {
    return this.alltask.find((item) => item.id === id);
  },
};

export default TaskOperation;
