class TaskType{
    id: string;
    title: string;
    desc: string;
    dateOfCreation: string;
    
    constructor(id:string,title:string,desc:string,dateOfCreation:string){
        this.id = id
        this.title = title,
        this.desc = desc,
        this.dateOfCreation = dateOfCreation
    }
}