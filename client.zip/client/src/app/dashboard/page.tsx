"use client";
import { Typography, Box, Container, Button } from "@mui/material";

import { useSession } from "next-auth/react";
import React from "react";

const DashBoard = () => {
  const { data } = useSession();
  return (
    <Container>
      <Box
        sx={{
          width: "50%",
          margin: "25px auto",
          textAlign: "center",
          backgroundColor: "Highlight",
        }}
      >
        <Typography variant="h6">User Name : {data?.user?.name}</Typography>
        <Typography variant="subtitle2">
          User Email : {data?.user?.email}
        </Typography>
        <Button>Change Password</Button>
      </Box>
    </Container>
  );
};

export default DashBoard;
