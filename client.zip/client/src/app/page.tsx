import { Box, Container, Typography } from "@mui/material";
import Link from "next/link";
import connection from "@/shared/database/mongodbConnection";
import NavBar from "@/shared/components/NavBar";

export default function Home() {
  connection();
  return (
    <>
      <NavBar />
      <Container>
        <Box sx={{ marginTop: "200px", width: "100%", textAlign: "center" }}>
          <Typography variant="h2">Welcome To Task Manager</Typography>
          <Typography variant="h4">
            To Use The Task Manager services please Login to website
          </Typography>
          <Link
            href={"/login"}
            style={{ textDecoration: "none", fontSize: "2em" }}
          >
            Login
          </Link>{" "}
          /{" "}
          <Link
            href={"/register"}
            style={{ textDecoration: "none", fontSize: "2em" }}
          >
            Register
          </Link>
        </Box>
      </Container>
    </>
  );
}
