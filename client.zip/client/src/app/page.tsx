import Image from "next/image";
import styles from "./page.module.css";
import { Box, Container,Typography } from "@mui/material";
import Link from "next/link";


export default function Home() {
  return <>
  <Container>
    <Box sx={{marginTop:'200px', width:'100%' ,textAlign:"center"}}>
      <Typography variant="h2">
      Welcome To Task Manager
      </Typography>
      <Typography variant="h4">
        To Use The Task Manager services please Login to website 
      </Typography>
     <Link href={'/login'} style={{textDecoration:'none' ,fontSize:'2em'}}>Login</Link> / <Link href={'/register'} style={{textDecoration:'none' ,fontSize:'2em'}}>Register</Link>
    </Box>
  </Container>
  </>;
}
