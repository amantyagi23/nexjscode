"use client";
import { Box, Button, Container, TextField } from "@mui/material";
import { signIn, useSession } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { SyntheticEvent, useRef, useState } from "react";
import { toast } from "react-toastify";
interface LoginData {
  email: string;
  password: string;
}

const Login = () => {
  const router = useRouter();

  // const { data: session } = useSession();
  const [name, setName] = useState<string>();

  const emailRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);

  const handleLogin = async (e: SyntheticEvent) => {
    e.preventDefault();

    try {
      const loginInfo = {
        email: emailRef.current?.value,
        password: passwordRef.current?.value,
      };
      const res = await fetch("/api/login", {
        method: "POST",
        headers: {
          "content-type": "application/json",
        },
        body: JSON.stringify(loginInfo),
      });

      if (res.ok) {
        toast.success("Login Successfully");
        signIn("credentials", {
          ...loginInfo,
          callbackUrl: "/task",
          redirect: true,
        });
      } else {
        toast.error("Error occur while Login");
        console.log("Error occur while Login");
      }
    } catch (error) {
      toast.error("Login unsuccessfully");
      console.log(error);
    }
  };
  return (
    <>
      <Container>
        <Box sx={{ width: "100%", textAlign: "center", margin: "20px" }}>
          <form
            onSubmit={(e: SyntheticEvent) => {
              handleLogin(e);
            }}
          >
            <Box
              sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                flexDirection: "column",
              }}
            >
              <TextField
                inputRef={emailRef}
                label="Email"
                margin="dense"
                sx={{ width: "60%" }}
              />
              <TextField
                inputRef={passwordRef}
                label="Password"
                margin="dense"
                sx={{ width: "60%" }}
              />
              <Button
                type="submit"
                variant="outlined"
                sx={{ margin: "20px", width: "40%" }}
              >
                Login
              </Button>
            </Box>
          </form>
          <Link href={"/register"}>Create A Account</Link>
        </Box>
      </Container>
    </>
  );
};

export default Login;
