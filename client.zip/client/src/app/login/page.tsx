"use client";
import connection from "@/shared/services/mongoDbConnection";
import { Box, Button, Container, TextField } from "@mui/material";
import { signIn, useSession } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import React, { useRef, useState } from "react";
interface LoginData {
  email: string;
  password: string;
}

const Login = () => {
  const router = useRouter();
  
  // const { data: session } = useSession();
  const [name, setName] = useState<string>();

  const emailRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);
 
  const login = () => {
    const loginInfo = {
      email: emailRef.current?.value,
      password: passwordRef.current?.value,
    };
 
    router.push("/task");
  };
  return (
    <>
      <Container>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
          }}
        >
          <TextField inputRef={emailRef} label="Email" margin="dense" />
          <TextField inputRef={passwordRef} label="Password" margin="dense" />
          <Button
            onClick={() => {
              login();
            }}
          >
            Login
          </Button>
          <Link href={"/register"}>Create A Account</Link>
        </Box>
        {/* {session?.user?.name} */}
      </Container>
    </>
  );
};

export default Login;
