"use client";
import { useParams, useRouter } from "next/navigation";
import React from "react";

const Update = () => {
  const router = useParams();
  const { id } = router;

  return <div>Update {id}</div>;
};

export default Update;
