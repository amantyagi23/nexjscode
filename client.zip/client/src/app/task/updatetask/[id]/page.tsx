"use client";
import { useParams, useRouter } from "next/navigation";
import React,{SyntheticEvent, useEffect, useState} from "react";
import TaskOperation from "../../services/services";

import {TextField ,Container,Box,Button} from '@mui/material'
import { SyntheticExpression } from "typescript";

interface TaskType{
  id: string;
  title: string;
  desc: string;
  dateOfCreation: string;
}

const Update :React.FC= () => {
  const router = useParams();
  const  {id}  = router;

  const [taskData, settaskData] = useState<TaskType>()

  const getTaskData =  ()=>{
    try {
      
    const findedTask = TaskOperation.searchTask(id);
    console.log(findedTask);
    settaskData(findedTask);
    } catch (error) {
      
    }
  }

  useEffect(()=>{
    getTaskData()
  },[id])

  const handleSubmit=(e:SyntheticEvent)=>{
    e.preventDefault()
  }

  return <Container >
 <Box sx={{margin:'5px 15px'}}>
 {taskData==undefined?"Invalid id":<Box>
    <h4>{taskData.id}</h4>
    <h5>Creation Data : {taskData.dateOfCreation}</h5>

    <form onSubmit={(e:SyntheticEvent)=>{handleSubmit(e)}}>
    <TextField label='Title' value={taskData.title} fullWidth/>
    <TextField label='Description' value={taskData.desc} fullWidth/>
    <Button type="submit">Update</Button>
    </form>
    </Box>
    }
 </Box>


  
  </Container>;
};

export default Update;
