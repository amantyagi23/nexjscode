"use client";
import { useParams, useRouter } from "next/navigation";
import React, { SyntheticEvent, useEffect, useState } from "react";
import TaskOperation from "../../../../modules/task/services/services";

import { TextField, Container, Box, Button } from "@mui/material";

interface TaskType {
  id: string;
  title: string;
  desc: string;
  dateOfCreation: string;
}

const Update: React.FC = () => {
  const params = useParams();
  const router = useRouter();
  const { id } = params;

  const [taskData, setTaskData] = useState<TaskType>();

  const getTaskData = () => {
    try {
      const findTask = TaskOperation.searchTask(id);
      console.log(findTask);

      setTaskData(findTask);
    } catch (error) {}
  };

  useEffect(() => {
    getTaskData();
  }, []);

  const handleSubmit = (e: SyntheticEvent) => {
    e.preventDefault();
    if (taskData) {
      TaskOperation.updateTask(taskData);
      router.push("/task");
    }
  };

  return (
    <Container>
      <Box sx={{ margin: "5px 15px" }}>
        {taskData == undefined ? (
          "Invalid id"
        ) : (
          <Box sx={{ margin: "25px 20px" }}>
            <h5>Creation Data : {taskData.dateOfCreation}</h5>

            <form
              onSubmit={(e: SyntheticEvent) => {
                handleSubmit(e);
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <TextField
                  label="Title"
                  value={taskData.title}
                  onChange={(e) => {
                    setTaskData({ ...taskData, title: e.target.value });
                  }}
                  margin="dense"
                  sx={{ width: "60%" }}
                />
                <TextField
                  label="Description"
                  value={taskData.desc}
                  onChange={(e) => {
                    setTaskData({ ...taskData, desc: e.target.value });
                  }}
                  margin="dense"
                  sx={{ width: "60%" }}
                />
                <Button
                  type="submit"
                  sx={{ width: "30%", margin: "20px auto" }}
                  variant="outlined"
                >
                  Update
                </Button>
              </Box>
            </form>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default Update;
