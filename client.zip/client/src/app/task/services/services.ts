import data from "./data";


const TaskOperation ={

    alltask :<TaskType[]>[],

    getAllTask(){
        const dataTasks = data.allTaskData;
        this.alltask = dataTasks;
        return this.alltask

    },
    addTask(taskObj:TaskType){
        this.alltask.push(taskObj);
    },
    updateTask(){

    },
    deleteTask(id:string){
        const afterDelete = this.alltask.filter((item) => item.id !== id);
        this.alltask = afterDelete;
        return this.alltask;
    },
    searchTask(id:any){
        return this.alltask.find((item)=>item.id === id);
    }
}

export default TaskOperation;