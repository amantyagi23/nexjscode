const data = {
  allTaskData: [
    
  ],
};

export default data;
