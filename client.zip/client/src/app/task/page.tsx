"use client";
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Container,
  IconButton,
  TextField,
  Typography,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import React, { useEffect, useState } from "react";

import { useRouter } from "next/navigation";

import TaskOperation from "../../modules/task/services/services";
import { useSession } from "next-auth/react";
import { toast } from "react-toastify";

interface TaskType {
  id: string;
  title: string;
  desc: string;
  dateOfCreation: string;
}

const TaskManager: React.FC<TaskType> = () => {
  const router = useRouter();
  const [taskData, setTaskData] = useState<TaskType[]>();
  const { data, status } = useSession({
    required: true,
    onUnauthenticated() {
      router.push("/login");
    },
  });

  useEffect(() => {
    const taskData = TaskOperation.getAllTask();
    setTaskData(taskData);
  }, []);
  const deleteTask = (id: string) => {
    const afterDelete = TaskOperation.deleteTask(id);
    setTaskData(afterDelete);
    toast.success("Task Deleted Successfully");
  };
  const editTask = (id: string) => {
    router.push(`/task/updatetask/${id}`);
  };
  if (status === "authenticated") {
    return (
      <Container>
        <Box
          sx={{
            display: "flex",
            flexDirection: "row",
            justifyContent: "space-between",
            margin: "20px ",
          }}
        >
          <TextField label="Search task" sx={{ width: "60%" }} />
          <Button
            variant="outlined"
            color="error"
            onClick={() => {
              router.push("/task/addtask");
            }}
          >
            {" "}
            Add Task
          </Button>
        </Box>
        {taskData?.map((item) => {
          return (
            <Card key={item.id} sx={{ margin: "10px 10px" }}>
              <CardContent>
                <Typography variant="h5">{item.title}</Typography>
                <Typography variant="subtitle2">{item.desc}</Typography>
              </CardContent>
              <CardActions>
                <IconButton
                  onClick={() => {
                    deleteTask(item.id);
                  }}
                  color="error"
                >
                  <DeleteIcon />
                </IconButton>
                <IconButton
                  onClick={() => {
                    editTask(item.id);
                  }}
                  color="info"
                >
                  <EditIcon />
                </IconButton>
              </CardActions>
            </Card>
          );
        })}
      </Container>
    );
  } else {
    return <></>;
  }
};

export default TaskManager;
