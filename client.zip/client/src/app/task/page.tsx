"use client";
import {
  Box,
  Button,
  Card,
  CardActions,
  CardContent,
  Container,
  IconButton,
  TextField,
  Typography,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import Link from "next/link";
import React, { useEffect, useState } from "react";

import { useRouter } from "next/navigation";
import data from "./services/data";
import TaskOperation from "./services/services";

interface TaskType {
  id: string;
  title: string;
  desc: string;
  dateOfCreation: string;
}

const TaskManager: React.FC<TaskType> = () => {
  const router = useRouter();
  const [taskData, setTaskData] = useState<TaskType[]>();

  useEffect(() => {
    const taskData = TaskOperation.getAllTask();
    setTaskData(taskData);
  }, []);
  const deleteTask = (id: string) => {
    const afterDelete =  TaskOperation.deleteTask(id);
    setTaskData(afterDelete);
  };
  const editTask = (id: string) => {
    router.push(`/task/updatetask/${id}`);
  };
  return (
    <Container>
      <Box
        sx={{
          display: "flex",
          flexDirection: "row",
          justifyContent: "space-between",
          margin: "20px ",
        }}
      >
        <TextField label="Search task" />
        <Link href={"/task/addtask"}>Add Task</Link>
      </Box>
      {taskData?.map((item) => {
        return (
          <Card key={item.id}>
            <CardContent>
              <Typography variant="h4">{item.title}</Typography>
              <Typography variant="h6">{item.desc}</Typography>
            </CardContent>
            <CardActions>
              <IconButton
                onClick={() => {
                  deleteTask(item.id);
                }}
                color="error"
              >
                <DeleteIcon />
              </IconButton>
              <IconButton
                onClick={() => {
                  editTask(item.id);
                }}
                color="info"
              >
                <EditIcon />
              </IconButton>
            </CardActions>
          </Card>
        );
      })}
    </Container>
  );
};

export default TaskManager;
