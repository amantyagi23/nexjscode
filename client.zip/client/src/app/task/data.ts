const data = {
  taskData: [
    {
      id: "1",
      dateOfCreation: "2023-08-26T10:00:00Z",
      title: "Meeting with Team",
      desc: "Discuss project updates and assign tasks.",
    },
    {
      id: "2",
      dateOfCreation: "2023-08-25T15:30:00Z",
      title: "Buy Groceries",
      desc: "Milk, eggs, vegetables, and fruits.",
    },
    {
      id: "3",
      dateOfCreation: "2023-08-24T09:45:00Z",
      title: "Gym Session",
      desc: "Cardio and strength training.",
    },
    {
      id: "4",
      dateOfCreation: "2023-08-23T14:20:00Z",
      title: "Read Book",
      desc: "Continue reading 'The Great Gatsby.'",
    },
    {
      id: "5",
      dateOfCreation: "2023-08-22T17:00:00Z",
      title: "Write Blog Post",
      desc: "Topic: Productivity Tips.",
    },
    {
      id: "6",
      dateOfCreation: "2023-08-21T11:10:00Z",
      title: "Project Deadline",
      desc: "Submit project proposal by EOD.",
    },
    {
      id: "7",
      dateOfCreation: "2023-08-20T08:45:00Z",
      title: "Call Client",
      desc: "Discuss project requirements and budget.",
    },
    {
      id: "8",
      dateOfCreation: "2023-08-19T13:15:00Z",
      title: "Family Dinner",
      desc: "Dinner with parents at the new restaurant.",
    },
    {
      id: "9",
      dateOfCreation: "2023-08-18T16:30:00Z",
      title: "Movie Night",
      desc: "Watch 'Inception' with friends.",
    },
    {
      id: "10",
      dateOfCreation: "2023-08-17T12:00:00Z",
      title: "Plan Weekend Getaway",
      desc: "Research and plan activities for the trip.",
    },
  ],
};

export default data;
