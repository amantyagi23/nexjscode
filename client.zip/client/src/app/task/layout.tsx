import NavBar from "@/shared/components/NavBar";

export default function TaskLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <>
      <NavBar />
      {children}
    </>
  );
}
