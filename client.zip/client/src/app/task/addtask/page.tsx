"use client";
import { Box, Button, Container, TextField } from "@mui/material";
import { useRouter } from "next/navigation";
import React, { useRef } from "react";
import { v4 as uuidv4 } from "uuid";

const AddTask = () => {
  const router = useRouter();
  const titleRef = useRef<HTMLInputElement>();
  const descRef = useRef<HTMLInputElement>();
  const uuid = uuidv4();
  const date = new Date();
  const creationData: string = `${date.getSeconds()}/${
    date.getMonth() + 1
  }/${date.getFullYear()}`;
  const addToDoTask = () => {
    const newTask = {
      id: uuid,
      title: titleRef.current?.value,
      desc: descRef.current?.value,
      dataOfCreation: creationData,
    };

    router.back();
  };
  return (
    <Container>
      <Box
        sx={{
          margin: "20px",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <TextField
          label="Enter Task Title"
          sx={{ width: "60%" }}
          margin="dense"
          inputRef={titleRef}
        />
        <TextField
          label="Enter Task Description"
          sx={{ width: "60%" }}
          margin="dense"
          inputRef={descRef}
        />
        <Button
          color="success"
          sx={{ width: "30%", marginTop: "15px" }}
          variant="contained"
          onClick={() => {
            addToDoTask();
          }}
        >
          Submit
        </Button>
      </Box>
    </Container>
  );
};

export default AddTask;
