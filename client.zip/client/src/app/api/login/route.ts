import userModel from "@/shared/database/models/userModel";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json();

    const userInfo = await userModel.findOne({ email });

    if (userInfo && userInfo._id) {
      if (password == userInfo.password) {
        return NextResponse.json(
          { message: "Login Successfully" },
          { status: 201 }
        );
      } else {
        return NextResponse.json(
          { message: "Invalid email and password" },
          { status: 404 }
        );
      }
    } else {
      return NextResponse.json(
        { message: "Invalid email and password" },
        { status: 404 }
      );
    }
  } catch (error) {
    return NextResponse.json(
      { message: "Internal server error" },
      { status: 500 }
    );
  }
}
