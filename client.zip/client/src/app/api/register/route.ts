import userModel from "@/shared/database/models/userModel";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, phone } = await request.json();
    console.log(name, email, password, phone);

    const existUser = await userModel.findOne({ email });

    if (existUser) {
      return NextResponse.json(
        { message: "User Already Exist " },
        { status: 201 }
      );
    }
    const dbResp = await userModel.create({ name, email, password });

    if (dbResp && dbResp._id) {
      return NextResponse.json(
        { message: "Successfully register" },
        { status: 201 }
      );
    } else {
      return NextResponse.json(
        { message: "Invalid register" },
        { status: 401 }
      );
    }
  } catch (error) {
    return NextResponse.json(
      { message: "Internal Server Error" },
      { status: 500 }
    );
  }
}
