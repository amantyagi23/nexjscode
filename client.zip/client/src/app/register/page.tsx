"use client";
import { Box, Button, Container, TextField } from "@mui/material";
import React, { SyntheticEvent, useRef } from "react";

const Register = () => {
  const emailRef = useRef<HTMLInputElement>();
  const nameRef = useRef<HTMLInputElement>();
  const passwordRef = useRef<HTMLInputElement>();
  const phoneRef = useRef<HTMLInputElement>();

  const handleSubmit= async(e:SyntheticEvent)=>{
    e.preventDefault();
    
    try {
      const userData = {
        name:nameRef.current?.value,
        email:emailRef.current?.value,
        phone:phoneRef.current?.value,
        password:passwordRef.current?.value
      }
      console.log(userData);
     const res =  await fetch('/api/register',{
        method:"POST",
        headers:{
          "content-type":"application/json"
        },
        body:JSON.stringify(userData)
      })

      if(res.ok){
        const form  = document.getElementById('form')
        console.log("yess data send");
        console.log(res.status,res.json());
        
      }

      
    } catch (error) {
      
    }
    return
    
  }

  return (
    <Container>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "center",
          width: "60%",
          margin: "0 auto",
        }}
      >
        <form id="form"  onSubmit={(e:SyntheticEvent)=>{handleSubmit(e)}}>
          <TextField
          inputRef={nameRef}
            label="Enter Name"
            margin="dense"
            sx={{ width: "100%" }}
            type="text"
            required
          />
          <TextField
          inputRef={emailRef}
            label="Enter Email"
            margin="dense"
            sx={{ width: "100%" }}
            type="email"
            required
          />
          <TextField
          inputRef={phoneRef}
            label="Enter Phone"
            margin="dense"
            sx={{ width: "100%" }}
            type="tel"
            required
          />
          <TextField
          inputRef={passwordRef}
            label="Enter Password"
            margin="dense"
            sx={{ width: "100%" }}
            type="password"
            required
          />
          <Button type="submit">Submit</Button>
          <Button type="reset">reset</Button>
        </form>
      </Box>
    </Container>
  );
};

export default Register;
