"use client";
import { Box, Button, Container, TextField } from "@mui/material";
import React, { useRef } from "react";

const Register = () => {
  const emailRef = useRef<HTMLInputElement>();
  const nameRef = useRef<HTMLInputElement>();
  const passwordRef = useRef<HTMLInputElement>();
  const phoneRef = useRef<HTMLInputElement>();

  return (
    <Container>
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          alignItems: "center",
          width: "60%",
          margin: "0 auto",
        }}
      >
        <form>
          <TextField
            label="Enter Email"
            margin="dense"
            sx={{ width: "100%" }}
          />
          <TextField
            label="Enter Email"
            margin="dense"
            sx={{ width: "100%" }}
          />
          <TextField
            label="Enter Email"
            margin="dense"
            sx={{ width: "100%" }}
          />
          <TextField
            label="Enter Email"
            margin="dense"
            sx={{ width: "100%" }}
          />
          <Button>Submit</Button>
        </form>
      </Box>
    </Container>
  );
};

export default Register;
