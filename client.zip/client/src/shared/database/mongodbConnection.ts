import mongoose from "mongoose";
const connection = () => {
  const URL: string =
    "mongodb+srv://amantyagi4987:admin123@cluster0.iyhsv1d.mongodb.net/taskmanagernext?retryWrites=true&w=majority";
  mongoose
    .connect(URL)
    .then(() => {
      console.log("SuccessFully Connected");
    })
    .catch((error) => {
      console.log(error);
    });
};

export default connection;
